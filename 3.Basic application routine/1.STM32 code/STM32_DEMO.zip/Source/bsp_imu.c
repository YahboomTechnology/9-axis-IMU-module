#include "bsp_imu.h"
#include "string.h"
#include "math.h"

IMUData_Packet_t IMUData;
AHRSData_Packet_t AHRSData;


uint8_t temp_data[64];
uint8_t raw_imu[64];
uint8_t raw_ahrs[56];
int new_imu_data = 0;
int new_ahrs_data = 0;

uint8_t Count = 0;
uint8_t last_rsnum = 0;
uint8_t rx_imu_flag = 0;
uint8_t rx_ahrs_flag = 0;


// 接收串口数据，判断是否符合协议
// Receives serial port data and checks whether it complies with the protocol
void Rx_imu_data(uint8_t rx_temp)
{
    temp_data[Count] = rx_temp;
    if (((last_rsnum == FRAME_END) && (rx_temp == FRAME_HEAD)) || Count > 0)
    {
        Count++;
        if ((temp_data[1] == TYPE_IMU) && (temp_data[2] == IMU_LEN))
            rx_imu_flag = 1;
        if ((temp_data[1] == TYPE_AHRS) && (temp_data[2] == AHRS_LEN))
            rx_ahrs_flag = 1;
    }
    else
        Count = 0;
    last_rsnum = rx_temp;

    if (rx_imu_flag == 1 && Count == IMU_RS)
    {
        Count = 0;
        rx_imu_flag = 0;
        new_imu_data = 1;
        if (temp_data[IMU_RS - 1] == FRAME_END)
            memcpy(raw_imu, temp_data, sizeof(temp_data));
    }
    if (rx_ahrs_flag == 1 && Count == AHRS_RS)
    {
        Count = 0;
        rx_ahrs_flag = 0;
        new_ahrs_data = 1;
        if (temp_data[AHRS_RS - 1] == FRAME_END)
            memcpy(raw_ahrs, temp_data, sizeof(temp_data));
    }
}

// generated data  合成数据
float Makeup_Data(uint8_t Data_1, uint8_t Data_2, uint8_t Data_3, uint8_t Data_4)
{
    long long transition_32;
    float tmp = 0;
    int sign = 0;
    int exponent = 0;
    float mantissa = 0;
    transition_32 = 0;
    transition_32 |= Data_4 << 24;
    transition_32 |= Data_3 << 16;
    transition_32 |= Data_2 << 8;
    transition_32 |= Data_1;
    sign = (transition_32 & 0x80000000) ? -1 : 1;
    exponent = ((transition_32 >> 23) & 0xff) - 127;
    mantissa = 1 + ((float)(transition_32 & 0x7fffff) / 0x7fffff);
    tmp = sign * mantissa * pow(2, exponent);
    return tmp;
}

// Composite timestamp  合成时间戳
static uint32_t Makeup_Timestamp(uint8_t Data_1, uint8_t Data_2, uint8_t Data_3, uint8_t Data_4)
{
    uint32_t transition_32;
    transition_32 = 0;
    transition_32 |= Data_4 << 24;
    transition_32 |= Data_3 << 16;
    transition_32 |= Data_2 << 8;
    transition_32 |= Data_1;
    return transition_32;
}

// Print AHRS attitude data  打印AHRS姿态数据
void Print_AHRS_Data(void)
{
    printf("RPY-> %f, %f, %f\r\n", AHRSData.Roll, AHRSData.Pitch, AHRSData.Heading);

    // printf("RPY Speed-> %f, %f, %f\r\n", AHRSData.RollSpeed, AHRSData.PitchSpeed, AHRSData.HeadingSpeed);

    // printf("Quaternion-> %f, %f, %f, %f\r\n", AHRSData.Q1, AHRSData.Q2, AHRSData.Q3, AHRSData.Q4);

    // printf("AHRS Timestamp-> %d\r\n", AHRSData.Timestamp);
}

// Print raw data  打印原始数据
void Print_IMU_Data(void)
{
    // printf("Gyroscope-> %f, %f, %f\r\n", IMUData.Gyroscope_X, IMUData.Gyroscope_Y, IMUData.Gyroscope_Z);

    // printf("Accelerometer-> %f, %f, %f\r\n", IMUData.Accelerometer_X, IMUData.Accelerometer_Y, IMUData.Accelerometer_Z);

    // printf("IMU:The Magnetometer_X-> %f, %f, %f\r\n", IMUData.Magnetometer_X, IMUData.Magnetometer_Y, IMUData.Magnetometer_Z);

    // printf("IMU Timestamp->  %d\r\n", IMUData.Timestamp);
}

// 解析九轴惯性传感器模块的数据，并通过串口1打印出来。
// Parse the data of the 9-axis IMU module and print it out through serial port 1.
void Parse_imu_data(void)
{
    if (new_ahrs_data == 1)
    {
        if (raw_ahrs[1] == TYPE_AHRS && raw_ahrs[2] == AHRS_LEN)
        {
            AHRSData.RollSpeed = Makeup_Data(raw_ahrs[7], raw_ahrs[8], raw_ahrs[9], raw_ahrs[10]);       //横滚角速度 roll rate
            AHRSData.PitchSpeed = Makeup_Data(raw_ahrs[11], raw_ahrs[12], raw_ahrs[13], raw_ahrs[14]);   //俯仰角速度 pitch rate
            AHRSData.HeadingSpeed = Makeup_Data(raw_ahrs[15], raw_ahrs[16], raw_ahrs[17], raw_ahrs[18]); //偏航角速度 yaw rate

            AHRSData.Roll = Makeup_Data(raw_ahrs[19], raw_ahrs[20], raw_ahrs[21], raw_ahrs[22]);    //横滚角 roll angle
            AHRSData.Pitch = Makeup_Data(raw_ahrs[23], raw_ahrs[24], raw_ahrs[25], raw_ahrs[26]);   //俯仰角 pitch angle
            AHRSData.Heading = Makeup_Data(raw_ahrs[27], raw_ahrs[28], raw_ahrs[29], raw_ahrs[30]); //偏航角 yaw angle

            AHRSData.Q1 = Makeup_Data(raw_ahrs[31], raw_ahrs[32], raw_ahrs[33], raw_ahrs[34]);     //四元数 Quaternion
            AHRSData.Q2 = Makeup_Data(raw_ahrs[35], raw_ahrs[36], raw_ahrs[37], raw_ahrs[38]);
            AHRSData.Q3 = Makeup_Data(raw_ahrs[39], raw_ahrs[40], raw_ahrs[41], raw_ahrs[42]);
            AHRSData.Q4 = Makeup_Data(raw_ahrs[43], raw_ahrs[44], raw_ahrs[45], raw_ahrs[46]);
            AHRSData.Timestamp = Makeup_Timestamp(raw_ahrs[47], raw_ahrs[48], raw_ahrs[49], raw_ahrs[50]); //时间戳 timestamp
            Print_AHRS_Data();
        }
        new_ahrs_data = 0;
    }
    if (new_imu_data == 1)
    {
        if (raw_imu[1] == TYPE_IMU && raw_imu[2] == IMU_LEN)
        {
            IMUData.Gyroscope_X = Makeup_Data(raw_imu[7], raw_imu[8], raw_imu[9], raw_imu[10]); // 角速度 Angular velocity
            IMUData.Gyroscope_Y = Makeup_Data(raw_imu[11], raw_imu[12], raw_imu[13], raw_imu[14]);
            IMUData.Gyroscope_Z = Makeup_Data(raw_imu[15], raw_imu[16], raw_imu[17], raw_imu[18]);

            IMUData.Accelerometer_X = Makeup_Data(raw_imu[19], raw_imu[20], raw_imu[21], raw_imu[22]); //线加速度 Linear acceleration
            IMUData.Accelerometer_Y = Makeup_Data(raw_imu[23], raw_imu[24], raw_imu[25], raw_imu[26]);
            IMUData.Accelerometer_Z = Makeup_Data(raw_imu[27], raw_imu[28], raw_imu[29], raw_imu[30]);

            IMUData.Magnetometer_X = Makeup_Data(raw_imu[31], raw_imu[32], raw_imu[33], raw_imu[34]); //磁力计数据 magnetometer data
            IMUData.Magnetometer_Y = Makeup_Data(raw_imu[35], raw_imu[36], raw_imu[37], raw_imu[38]);
            IMUData.Magnetometer_Z = Makeup_Data(raw_imu[39], raw_imu[40], raw_imu[41], raw_imu[42]);

            IMUData.Timestamp = Makeup_Timestamp(raw_imu[55], raw_imu[56], raw_imu[57], raw_imu[58]); //时间戳 timestamp
            Print_IMU_Data();
        }
        new_imu_data = 0;
    }
}
