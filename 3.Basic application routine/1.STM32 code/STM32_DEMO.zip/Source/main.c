#include "stm32f10x.h"
#include "bsp.h"

int main(void)
{
	SystemInit();
	Bsp_Init();
	printf("Hello Yahboom!\n");     // 打印公司信息, 提示程序初始化完成。 The company information is printed, prompting that the program initialization is complete.

	while (1)
	{
		Parse_imu_data();
		Bsp_Led_Show_State();
		// delay_ms(1);
	}
}

#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
	/* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

	printf("Wrong parameters value: file %s on line %d\r\n", file, line);
	/* Infinite loop */
	while (1)
		;
}
#endif
