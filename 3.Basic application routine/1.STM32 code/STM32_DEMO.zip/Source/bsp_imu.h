#ifndef __BSP_IMU_H__
#define __BSP_IMU_H__
#include "stdint.h"
#include "stdio.h"

// FDlink candata
#define FRAME_HEAD 0xfc
#define FRAME_END 0xfd
#define TYPE_IMU 0x40
#define TYPE_AHRS 0x41

#define IMU_LEN 0x38    // 56+8  
#define AHRS_LEN 0x30   // 48+8  

#define IMU_RS 64
#define AHRS_RS 56


typedef struct IMUData_Packet_t
{
    float Gyroscope_X;          // unit: rad/s
    float Gyroscope_Y;          // unit: rad/s
    float Gyroscope_Z;          // unit: rad/s
    float Accelerometer_X;      // m/s^2
    float Accelerometer_Y;      // m/s^2
    float Accelerometer_Z;      // m/s^2
    float Magnetometer_X;       // mG
    float Magnetometer_Y;       // mG
    float Magnetometer_Z;       // mG
    float IMU_Temperature;      // C
    float Pressure;             // Pa
    float Pressure_Temperature; // C
    uint32_t Timestamp;         // unit: us
} IMUData_Packet_t;

typedef struct AHRSData_Packet_t
{
    float RollSpeed;    // unit: rad/s
    float PitchSpeed;   // unit: rad/s
    float HeadingSpeed; // unit: rad/s
    float Roll;         // unit: rad
    float Pitch;        // unit: rad
    float Heading;      // unit: rad
    float Q1;           // Q1          //Quaternion
    float Q2;           // Q2
    float Q3;           // Q3
    float Q4;           // Q4
    uint32_t Timestamp; // unit: us
} AHRSData_Packet_t;

void Rx_imu_data(uint8_t rx_temp);
void Parse_imu_data(void);

#endif /* __BSP_IMU_H__ */
