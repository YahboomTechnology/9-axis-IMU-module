#include "bsp.h"


static uint8_t fac_us = 0;  //us delay multiplier
static uint16_t fac_ms = 0; //ms delay multiplier


/**************************************************** *********
** Function name: delay_init Initialize delay function
** Function description: Initialization delay function, the clock of SYSTICK is fixed to 1/8 of the clock of HCLK
** Input parameter: SYSCLK (unit MHz)
** output parameter: none
** Calling method: If the system clock is set to 72MHz, then call delay_init(72)
** The system clock is 72M, 1/8 is 9M, that is, it vibrates 9000000 times per second, 1s=1000ms=1000000us => 1us vibrates 9 times
**************************************************** *********/
void delay_init(void)
{
	uint8_t SYSCLK = 72;
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);
	SysTick->CTRL |= SysTick_CTRL_TICKINT_Msk;
	SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;
	fac_us = SYSCLK / 8;
	fac_ms = (uint16_t)fac_us * 1000;
}

/**************************************************** *********
** function name: delay_ms
** Function description: Delay nms
** Input parameters: nms
** output parameter: none
** Note: SysTick->LOAD is a 24-bit register, so the maximum delay is:
		nms<=0xffffff*8*1000/SYSCLK
		SYSCLK unit is Hz, nms unit is ms
		Under the condition of 72M, nms<=1864
**************************************************** *********/
void delay_ms(uint16_t nms)
{
	uint32_t temp;
	SysTick->LOAD = (uint32_t)nms * fac_ms;
	SysTick->VAL = 0x00;
	SysTick->CTRL = 0x01;
	do
	{
		temp = SysTick->CTRL;
	} while (temp & 0x01 && !(temp & (1 << 16)));
	SysTick->CTRL = 0x00;
	SysTick->VAL = 0X00;
}


// Initialize LED lights
void LED_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(LED_GPIO_CLK, ENABLE);
	GPIO_InitStructure.GPIO_Pin = LED_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(LED_GPIO_PORT, &GPIO_InitStructure);
	LED_ON();
}

//JTAG mode setting, used to set the mode of JTAG
//mode: jtag, swd mode setting; 00, all enable; 01, enable SWD; 10, all off;
//#define JTAG_SWD_DISABLE   0X02
//#define SWD_ENABLE         0X01
//#define JTAG_SWD_ENABLE    0X00
void Bsp_JTAG_Set(uint8_t mode)
{
	uint32_t temp;
	temp = mode;
	temp <<= 25;
	RCC->APB2ENR |= 1 << 0;
	AFIO->MAPR &= 0XF8FFFFFF;
	AFIO->MAPR |= temp;
}


// LED indicator blinking
void Bsp_Led_Show_State(void)
{
	static uint16_t led_count = 0;
	static uint8_t led_flash = 0;
	led_count++;

	if (led_count >= 100)
	{
		led_count = 0;
		led_flash = !led_flash;
		if (led_flash)
		{
			LED_ON();
		}
		else
		{
			LED_OFF();
		}
	}
}


void Bsp_Init(void)
{
	delay_init();
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); //Set to priority group 2

	USART1_Init(USART1_BAUDRATE);
	USART2_Init(USART2_BAUDRATE);

	Bsp_JTAG_Set(SWD_ENABLE);
	LED_GPIO_Init();
}
