#ifndef __BSP_H__
#define __BSP_H__

#include "stdio.h"
#include "stdint.h"

#include "stm32f10x.h"
#include "bsp_usart.h"
#include "bsp_imu.h"


//JTAG Mode Setting Definition
#define JTAG_SWD_DISABLE       0X02
#define SWD_ENABLE             0X01
#define JTAG_SWD_ENABLE        0X00

#define LED_GPIO_CLK     RCC_APB2Periph_GPIOC
#define LED_GPIO_PORT    GPIOC
#define LED_GPIO_PIN     GPIO_Pin_13


#define LED_ON()         GPIO_ResetBits(LED_GPIO_PORT, LED_GPIO_PIN)
#define LED_OFF()        GPIO_SetBits(LED_GPIO_PORT, LED_GPIO_PIN)



void delay_init(void);
void delay_ms(uint16_t nms);
void delay_us(uint32_t nus);


void Bsp_Init(void);
void Bsp_JTAG_Set(uint8_t mode);
void Bsp_Led_Show_State(void);

#endif
